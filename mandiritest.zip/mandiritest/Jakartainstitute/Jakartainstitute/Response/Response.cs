﻿namespace Jakartainstitute.Response
{
    public class Response
    {
    }
}
