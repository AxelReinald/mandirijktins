﻿namespace Jakartainstitute.Response
{
    public class Pagging
    {
        public int totalData { get; set; }
        public int? prevPage { get; set; }
        public int pageNo { get; set; }
        public int? nextPage { get; set; }
        public int? totalPage { get; set; }
        public int entriesPage { get; set; }
    }
}
