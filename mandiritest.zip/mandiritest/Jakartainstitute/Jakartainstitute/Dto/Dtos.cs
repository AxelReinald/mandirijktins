﻿using Jakartainstitute.Models;

namespace Jakartainstitute.Dto
{
    public class Dtos
    {
    }

    public class DataPage
    {
        public object? data { get; set; }
        public object? infoPage { get; set; }
    }
    public class ReturnRespon
    {
        public object? data { get; set; }
        public string? message { get; set; }
    }
    public class ResponseCodes
    {
        public int ResponseCode { get; set; }
        public string ResponseMessage { get; set; }
        public object? Data { get; set; }
    }
    public class StudentwithPage
    {
        public List<Studentwithdepadv> data { get; set; }
        public Pagging info { get; set; }
    }
    public class Pagging
    {
        public int totalData { get; set; }
        public int? prevPageNo { get; set; }
        public int pageNo { get; set; }
        public int? nextpageNo { get; set; }
        public int totalPage { get; set; }
        public int entriesPerPage { get; set; }
    }
    public class UserPaging
    {
        public int pageNo { get; set; } = 1;
        public int entriesPerPage { get; set; } = 10;
    }
    public static class ConstantMessages
    {
        public const string SuccessMessage = "Successfully!";
        public const string FailMessage = "Fail!";
        public const string NoData = "Data Not Found";
    }
}
