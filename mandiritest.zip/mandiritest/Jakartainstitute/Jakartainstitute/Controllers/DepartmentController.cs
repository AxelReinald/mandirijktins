﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Repository;
using Jakartainstitute.Service;
using Microsoft.AspNetCore.Mvc;

namespace Jakartainstitute.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DepartmentController : ControllerBase
    {
        private readonly DepartmentService _departmentService;

        public DepartmentController(JakartainstituteDbContext context)
        {
            _departmentService = new DepartmentService(context);
        }
        [HttpGet("GetAllDepartment")]
        public IActionResult GetAllDepartment() 
        {
            var response = _departmentService.Getalldepart();
            if (response.Count > 0)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("No Data Available");
            }
        }
        
        [HttpPost("InsertDepartment")]
        public ActionResult InsertDepartment(Department department)
        {
          
            var response = _departmentService.Createnewdepart(department);
            if (response.ResponseCode == 200)
            {
                return Ok(response);

            }
            else
            {
                var respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = response.ResponseMessage
                };
                return BadRequest(respon);

            }
        }
    }
}
