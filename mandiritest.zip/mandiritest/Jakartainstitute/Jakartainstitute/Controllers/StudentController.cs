﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Service;
using Microsoft.AspNetCore.Mvc;

namespace Jakartainstitute.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly StudentService _studentService;

        public StudentController(JakartainstituteDbContext context)
        {
            _studentService = new StudentService(context);
        }

        [HttpGet("GetAllStudent")]
        public ActionResult GetAllStudent()
        {
            var students = _studentService.Getallstudents();
            if (students.Count > 0)
            {
                return Ok(students);
            }
            else
            {
                return BadRequest("No Data Available");
            }
            
        }

        [HttpPost("InsertStudent")]
        public ActionResult InsertStudent(Student student)
        {
            var response = _studentService.Createnewstudent(student);
            if (response.ResponseCode == 200)
            {
                return Ok(response);

            }
            else
            {
                return BadRequest(response);

            }

        }

        [HttpDelete("DeleteStudent/{id}")]
        public ActionResult<Student> DeleteStudent(int id)
        {
            var respon = _studentService.Deletestudent(id);
            if (respon.ResponseCode == 200)
            {
                return Ok(respon);

            }
            else
            {
                return BadRequest(respon);

            }
        }

        [HttpPost("GetStudentwithPagination")]
        public ActionResult GetStudentwithPagination(UserPaging paging)
        {
            var respon = _studentService.ContextGetStudentwithPagination(paging);
            if (respon.ResponseCode == 200)
            {
                return Ok(respon);

            }
            else
            {
                return BadRequest(respon);

            }
        }
        [HttpPut("UpdateDataStudent")]
        public ActionResult UpdateDataStudent(Student request)
        {
            var respon = _studentService.UpdateDataStudent(request);
            if (respon.ResponseCode == 200)
            {
                return Ok(respon);

            }
            else
            {
                return BadRequest(respon);

            }
        }
    }
}
