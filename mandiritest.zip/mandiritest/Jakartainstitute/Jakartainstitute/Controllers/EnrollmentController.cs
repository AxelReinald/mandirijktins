﻿using Jakartainstitute.Models;
using Jakartainstitute.Service;
using Microsoft.AspNetCore.Mvc;

namespace Jakartainstitute.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EnrollmentController : ControllerBase
    {
        private readonly EnrollmentService _enrollmentService;

        public EnrollmentController(JakartainstituteDbContext context)
        {
            _enrollmentService = new EnrollmentService(context);
        }

        [HttpPost("InsertEnrollment")]
        public ActionResult InsertStudent(Enrollment request)
        {
            var response = _enrollmentService.Createnewenrollment(request);
            if (response.ResponseCode == 200)
            {
                return Ok(response);

            }
            else
            {
                return BadRequest(response);

            }
        }
    }
}
