﻿using Jakartainstitute.Models;
using Jakartainstitute.Service;
using Microsoft.AspNetCore.Mvc;

namespace Jakartainstitute.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AdvisorController : ControllerBase
    {
        private readonly AdvisorService _service;

        public AdvisorController(JakartainstituteDbContext context)
        {
            _service = new AdvisorService(context);
        }

        [HttpPost("InsertAdvisor")]
        public ActionResult InsertAdvisor(Advisor adv)
        {
            var response = _service.InsertAdvisor(adv);
            if (response.ResponseCode == 200)
            {
                return Ok(response);

            }
            else
            {
                return BadRequest(response);

            }

        }
    }
}
