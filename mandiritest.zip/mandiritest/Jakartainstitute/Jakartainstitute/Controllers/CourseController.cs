﻿using Jakartainstitute.Models;
using Jakartainstitute.Repository;
using Jakartainstitute.Service;
using Microsoft.AspNetCore.Mvc;

namespace Jakartainstitute.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CourseController : ControllerBase
    {
        private readonly CourseService _courseService;

        public CourseController(JakartainstituteDbContext context)
        {
            _courseService = new CourseService(context);
        }

        [HttpGet("GetAllCourse")]
        public ActionResult GetAllCourse()
        {
            var course = _courseService.Getallcourse();
            if (course.Count > 0)
            {
                return Ok(course);
            }
            else
            {
                return BadRequest("No Data Available");
            }
        }
        [HttpPost("Insertnewcourse")]
        public ActionResult Insertnewcourse(Course course)
        {
            var response = _courseService.Insertnewcourse(course);
            if (response.ResponseCode == 200)
            {
                return Ok(response);

            }
            else
            {
                return BadRequest(response);

            }
        }
    }
}
