﻿using Microsoft.EntityFrameworkCore;

namespace Jakartainstitute.Models
{
    public class JakartainstituteDbContext : DbContext
    {
        public JakartainstituteDbContext(DbContextOptions<JakartainstituteDbContext> options) : base(options) { }

        public DbSet<Department> Department { get; set; }
        public DbSet<Student> Student { get; set; }
        public DbSet<Course> Course { get; set; }
        public DbSet<Enrollment> Enrollment { get; set; }
        public DbSet<Advisor> Advisor { get; set; }
    }
}
