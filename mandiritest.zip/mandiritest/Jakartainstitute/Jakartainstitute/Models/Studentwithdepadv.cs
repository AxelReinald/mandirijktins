﻿namespace Jakartainstitute.Models
{
    public class Studentwithdepadv
    {
        public int StudentID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? DepartmentID { get; set; }
        public Department? Department { get; set; }
        public Advisor? Advisor { get; set; }
    }
}
