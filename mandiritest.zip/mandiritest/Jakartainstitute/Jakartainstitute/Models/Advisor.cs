﻿namespace Jakartainstitute.Models
{
    public class Advisor
    {
        public int AdvisorID { get; set; }
        public int StudentID { get; set; }
    }
}
