﻿using System.Collections.Generic;

namespace Jakartainstitute.Models
{
    public class Course
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public int DepartmentID { get; set; }
    }

    public class Allcourse
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public int DepartmentID { get; set; }
        public Department Department { get; set; }
        public List<Enrollment> Enrollments { get; set; }
    }
}
