﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Microsoft.EntityFrameworkCore;

namespace Jakartainstitute.Repository
{
    public interface IStudent
    {

    }
    public class StudentRepo : IStudent
    {
        private JakartainstituteDbContext db;
        public StudentRepo(JakartainstituteDbContext db)
        {
            this.db = db;
        }

        public List<Student> Getaallstudentquery()
        {
            List<Student> students = new List<Student>();
            var query = db.Student.ToList();
            return query;
        }

        public List<Studentwithdepadv> GetallStudentwithPagination(UserPaging request, out int totalData)
        {

            List<Studentwithdepadv> students = new List<Studentwithdepadv>();
            var query = (from stud in db.Student
                         join depart in db.Department on stud.DepartmentID equals depart.DepartmentID
                         join advis in db.Advisor on stud.StudentID equals advis.StudentID
                         select new Studentwithdepadv
                         {
                             StudentID = stud.StudentID,
                             FirstName = stud.FirstName,
                             LastName = stud.LastName,
                             DepartmentID = stud.DepartmentID,
                             Department = depart,
                             Advisor = advis,
                         }).ToList();
            totalData = query.Count();
            return query.Skip((request.pageNo - 1 )* request.entriesPerPage).Take(request.entriesPerPage).ToList();
        }

        public ReturnRespon Contextdeletestudent(int id)
        {
            var item = db.Student.Find(id);
            if (item == null)
            {
                var result = new ReturnRespon
                {
                   message = "fail"
                };
                return result;
            }
            else
            {
                db.Student.Remove(item);
                db.SaveChanges();
                var result = new ReturnRespon
                {
                    data = item,
                    message = "success"
                };
                return result;
            }
           
        }

        public void Insertnewstudent(Student student)
        {
            db.Student.Add(student);
            db.SaveChanges();
        } 
        public void Updatestudent(Student student)
        {
            db.SaveChanges();
        }

        public Student OldStudent(string name)
        {
            var a = db.Student.Where(x => x.FirstName.Equals(name)).FirstOrDefault();
            return a;
        }
    }
}
