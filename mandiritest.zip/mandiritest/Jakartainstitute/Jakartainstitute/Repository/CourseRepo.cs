﻿using Jakartainstitute.Models;

namespace Jakartainstitute.Repository
{
    public interface ICourse
    {

    }
    public class CourseRepo : ICourse
    {
        private JakartainstituteDbContext db;

        public CourseRepo(JakartainstituteDbContext db)
        {
            this.db = db;
        }

        public List<Allcourse> Getallcoursequery()
        {
            List<Allcourse> courselist = new List<Allcourse>();
            var query = 
                (from cos in db.Course
                 join dep in db.Department on cos.DepartmentID equals dep.DepartmentID
                 select new Allcourse
                 {
                    CourseID = cos.CourseID,
                    CourseName = cos.CourseName,
                    DepartmentID = dep.DepartmentID,
                    Department = dep

                 });
            foreach (var course in query)
            {
                course.Enrollments = db.Enrollment.Where(y=>y.CourseID.Equals(course.CourseID)).ToList();
                courselist.Add(course);
            }
            return courselist;
        }

        public void Insertnewcourse(Course req)
        {
            db.Course.Add(req);
            db.SaveChanges();
        }
    }
}
