﻿using Jakartainstitute.Models;

namespace Jakartainstitute.Repository
{
    public interface IAdvisor { }
    public class AdvisorRepo : IAdvisor
    {
        private JakartainstituteDbContext db;
        public AdvisorRepo(JakartainstituteDbContext db)
        {
            this.db = db;
        }

        public void Insertnewadvisorrepo(Advisor request)
        {
            db.Advisor.Add(request);
            db.SaveChanges();
        }
    }
}
