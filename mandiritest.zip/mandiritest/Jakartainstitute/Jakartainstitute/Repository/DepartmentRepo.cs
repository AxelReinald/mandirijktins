﻿using Jakartainstitute.Models;

namespace Jakartainstitute.Repository
{
    public interface IDepartment
    {

    }
    public class DepartmentRepo : IDepartment
    {
        private JakartainstituteDbContext db;
        public DepartmentRepo(JakartainstituteDbContext db)
        {
            this.db = db;
        }

        public List<Department> Getalldepart()
        {
            var query = db.Department.ToList();
            return query;
        }

        public void Insertnewdepart(Department newdepart)
        {
            db.Department.Add(newdepart);
            db.SaveChanges();
        }
    }
}
