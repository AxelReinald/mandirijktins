﻿using Jakartainstitute.Models;

namespace Jakartainstitute.Repository
{
    public interface IEnrollment
    {

    }
    public class EnrollmentRepo : IEnrollment
    {
        private JakartainstituteDbContext db;
        public EnrollmentRepo(JakartainstituteDbContext db) 
        {
            this.db = db;
        }

        public void Createnewenrollmentrepo(Enrollment enrol)
        {
            enrol.EnrollmentDate = DateTime.Now;    
            db.Enrollment.Add(enrol);
            db.SaveChanges();
        }
    }
}
