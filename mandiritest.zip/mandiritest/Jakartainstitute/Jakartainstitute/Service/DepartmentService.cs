﻿using Jakartainstitute.Models;
using Jakartainstitute.Repository;
using Microsoft.IdentityModel.Tokens;
using Jakartainstitute.Dto;

namespace Jakartainstitute.Service
{
    public class DepartmentService
    {
        private DepartmentRepo _departmentRepo;
        public DepartmentService(DepartmentRepo departmentRepo)
        {
            _departmentRepo = departmentRepo;
        }
        public DepartmentService(JakartainstituteDbContext dbContext)
        {
            this._departmentRepo = new DepartmentRepo(dbContext);
        }

        public List<Department> Getalldepart()
        {
            return _departmentRepo.Getalldepart();
        }

        public ResponseCodes Createnewdepart(Department department)
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {
                if (!string.IsNullOrWhiteSpace(department.DepartmentName))
                {
                    _departmentRepo.Insertnewdepart(department);
                    respon = new ResponseCodes
                    {
                        ResponseCode = 200,
                        ResponseMessage = ConstantMessages.SuccessMessage,
                        Data = department
                    };

                }
                else
                {
                    throw new Exception("Nama Department Tidak boleh kosong");
                }
               
            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
           
            return respon;
        }
    }
}
