﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Repository;

namespace Jakartainstitute.Service
{
    public class AdvisorService
    {
        private AdvisorRepo repo;
        public AdvisorService(AdvisorRepo repo)
        {
            this.repo = repo;
        }
        public AdvisorService(JakartainstituteDbContext dbContext)
        {
            this.repo = new AdvisorRepo(dbContext);
        }
        public ResponseCodes InsertAdvisor(Advisor request)
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {

                repo.Insertnewadvisorrepo(request);
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = request
                };
            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
            return respon;
        }
    }
}
