﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Repository;

namespace Jakartainstitute.Service
{
    public class CourseService
    {
        private CourseRepo _courseRepo;

        public CourseService(CourseRepo _courseRepo)
        {
            this._courseRepo = _courseRepo;
        }

        public CourseService(JakartainstituteDbContext dbContext) 
        {
            this._courseRepo = new CourseRepo(dbContext);
        }

        public List<Allcourse> Getallcourse() 
        {
            return _courseRepo.Getallcoursequery();
        }

        public ResponseCodes Insertnewcourse(Course req)
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {

                _courseRepo.Insertnewcourse(req);
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = req
                };

            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
            return respon;
        }
    }
}
