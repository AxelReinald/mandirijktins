﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Repository;

namespace Jakartainstitute.Service
{
    public class EnrollmentService
    {
        private EnrollmentRepo _enrollmentRepo;
        public EnrollmentService(EnrollmentRepo _enrollmentRepo)
        {
            this._enrollmentRepo = _enrollmentRepo;
        }
        public EnrollmentService(JakartainstituteDbContext dbContext)
        {
            this._enrollmentRepo = new EnrollmentRepo(dbContext);
        }

        public ResponseCodes Createnewenrollment(Enrollment enrollment) 
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {
                _enrollmentRepo.Createnewenrollmentrepo(enrollment);
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = enrollment
                };
            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
            return respon;
        }
    }
}
