﻿using Jakartainstitute.Dto;
using Jakartainstitute.Models;
using Jakartainstitute.Repository;

namespace Jakartainstitute.Service
{
    public class StudentService
    {
        private StudentRepo _studentRepo;
        public StudentService(StudentRepo _studentRepo)
        {
            this._studentRepo = _studentRepo;
        }
        public StudentService(JakartainstituteDbContext dbContext)
        {
            this._studentRepo = new StudentRepo(dbContext);
        }

        public List<Student> Getallstudents()
        {
            return _studentRepo.Getaallstudentquery();
        }

        public ResponseCodes Deletestudent(int id)
        {
            ResponseCodes respon = new ResponseCodes();
            var result = _studentRepo.Contextdeletestudent(id);
            if (result.message == "success")
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = result.data
                };
            }
            else
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.FailMessage
                };
            }
            return respon;
        }

        public ResponseCodes ContextGetStudentwithPagination(UserPaging request)
        {
            int totalData;

            var resultdata = _studentRepo.GetallStudentwithPagination(request, out totalData);

            var totalPage = request.entriesPerPage == 0 ? 0 : (totalData /  request.entriesPerPage) + 1;

            if(resultdata.Count > 0) 
            {
                return new ResponseCodes()
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = new StudentwithPage()
                    {
                        data = resultdata,
                        info = new Pagging()
                        {
                            totalData = totalData,
                            prevPageNo = request.pageNo <= 1 ? null : request.pageNo - 1,
                            pageNo = request.pageNo,
                            nextpageNo = request.pageNo + 1 > totalPage ? null : request.pageNo + 1,
                            totalPage = totalPage,
                            entriesPerPage = request.entriesPerPage
                        }
                    }
                };
            }
            else
            {
                return new ResponseCodes()
                {
                    ResponseCode = 400,
                    ResponseMessage = ConstantMessages.NoData,
                };
            }
        }

        public ResponseCodes Createnewstudent(Student student)
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {
                if (!string.IsNullOrWhiteSpace(student.FirstName))
                {
                    _studentRepo.Insertnewstudent(student);
                    respon = new ResponseCodes
                    {
                        ResponseCode = 200,
                        ResponseMessage = ConstantMessages.SuccessMessage,
                        Data = student
                    };
                }
                else
                {
                    throw new Exception("First Name Can't be Null");
                }
            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
            return respon;
        }
        public ResponseCodes UpdateDataStudent(Student student)
        {
            ResponseCodes respon = new ResponseCodes();
            try
            {
                var oldstudent = _studentRepo.OldStudent(student.FirstName);
                oldstudent.StudentID = oldstudent.StudentID;
                oldstudent.FirstName = student.FirstName;
                oldstudent.LastName = student.LastName;
                oldstudent.Address = student.Address;
                oldstudent.Phonenumber = student.Phonenumber;
                oldstudent.DepartmentID = student.DepartmentID != null ? student.DepartmentID : oldstudent.DepartmentID;
                _studentRepo.Updatestudent(oldstudent);
                respon = new ResponseCodes
                {
                    ResponseCode = 200,
                    ResponseMessage = ConstantMessages.SuccessMessage,
                    Data = oldstudent
                };

            }
            catch (Exception ex)
            {
                respon = new ResponseCodes
                {
                    ResponseCode = 400,
                    ResponseMessage = ex.Message
                };
                return respon;
            }
            return respon;
        }
    }
}
